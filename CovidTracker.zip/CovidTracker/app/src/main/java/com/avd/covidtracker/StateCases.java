package com.avd.covidtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.avd.covidtracker.Connection.ApiClient;
import com.avd.covidtracker.Interfaces.ApiInterface;
import com.avd.covidtracker.Pojo.DistCovids;
import com.avd.covidtracker.Pojo.StateCovids;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StateCases extends AppCompatActivity {

    ApiInterface apiInterface;

    Spinner spinState;
    Spinner spinDist;

    List<StateCovids> stateCovidList;
    List<DistCovids> distCovidList;
    ArrayAdapter<StateCovids> adapter;
    ArrayAdapter<DistCovids> distAdapter;

    DistCovids distItem;

    TextView tvStActive,tvStConfirm, tvStRecover, tvStDeath, tvDistConfirm;

    String a,c,r,d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_state_cases);

        spinState = findViewById(R.id.spinState);
        spinDist = findViewById(R.id.spinDist);

        tvStActive = findViewById(R.id.tv_stActive);
        tvStConfirm = findViewById(R.id.tv_stConfirm);
        tvStRecover = findViewById(R.id.tv_stRecover);
        tvStDeath = findViewById(R.id.tv_stDeath);
        tvDistConfirm = findViewById(R.id.tv_distConfirm);

        stateCovidList = new ArrayList<>();
        stateCovidList.clear();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,stateCovidList);

        distCovidList = new ArrayList<>();
        distCovidList.clear();
        distAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,distCovidList);

        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);

        Call<List<StateCovids>> call = apiInterface.getStateCases();

        call.enqueue(new Callback<List<StateCovids>>() {
            @Override
            public void onResponse(Call<List<StateCovids>> call, Response<List<StateCovids>> response) {
                if(response.isSuccessful()) {
                    for (StateCovids row : response.body()) {
                        a = ""+row.getActive();
                        c = ""+row.getConfirmed();
                        r = ""+row.getRecovered();
                        d = ""+row.getDeaths();
                        System.out.println("State Active: "+a);
                        System.out.println("State Confirmed: "+c);
                        System.out.println("State Recovered: "+r);
                        System.out.println("State Deaths: "+d);
                        System.out.println("Districts List: "+row.getDistricts());
                        String id = ""+row.getId();
                        String name = ""+row.getState();
                        long ac = row.getActive();
                        long con = row.getConfirmed();
                        long rec = row.getRecovered();
                        long dt = row.getDeaths();

                        StateCovids stateCovids = new StateCovids(id, name, ac,con,rec,dt,row.getDistricts());
                        stateCovidList.add(stateCovids);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinState.setAdapter(adapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<List<StateCovids>> call, Throwable t) {
                Toast.makeText(StateCases.this, "UNABLE TO FETCH, Check your internet connection.", Toast.LENGTH_LONG).show();
            }
        });

            /*
            adapter = new ArrayAdapter(StateCases.this,android.R.layout.simple_spinner_item,stateCovidList);
            StateCovids stCovid = new StateCovids("IN-MH","Maharashtra",261313,1416513,1117720,37480);
            Gson gson = new Gson();
            String stateJson = gson.toJson(stCovid);
            System.out.println(stateJson);
            stCovid = gson.fromJson(stateJson,StateCovids.class);
            System.out.println(stCovid.getActive());
            */


        // for state spinner
        spinState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                System.out.println("LIST: "+stateCovidList);
                tvStActive.setText(String.valueOf(stateCovidList.get(i).getActive()));
                tvStConfirm.setText(String.valueOf(stateCovidList.get(i).getConfirmed()));
                tvStRecover.setText(String.valueOf(stateCovidList.get(i).getRecovered()));
                tvStDeath.setText(String.valueOf(stateCovidList.get(i).getDeaths()));

                distCovidList.clear();
                for(DistCovids district:stateCovidList.get(i).getDistricts()){
//                    System.out.println("dist name: "+district);
                    distCovidList.add(district);
                }

//                distItem = new DistCovids(String.valueOf(stateCovidList.get(i).getDistricts()),String.valueOf(stateCovidList.get(i).getDistricts()),stateCovidList.get(i).getConfirmed());
                distAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinDist.setAdapter(distAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(StateCases.this, "Select an item from dropdown.", Toast.LENGTH_SHORT).show();
            }
        });


        // for district spinner
        spinDist.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tvDistConfirm.setText(String.valueOf(distCovidList.get(i).getConfirmed()));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void totalCases(View view) {
        startActivity(new Intent(this,TotalCases.class));
    }

    public void stateApi(View view) {
    }

//    private void getStateRecord(){
//        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
//        Call<List<StateCovids>> call = apiInterface.getStateCases();
//
//        System.out.println("Call: "+call);
//
//        call.enqueue(new Callback<List<StateCovids>>() {
//            @Override
//            public void onResponse(Call<List<StateCovids>> call, Response<List<StateCovids>> response) {
//
//            }
//
//            @Override
//            public void onFailure(Call<List<StateCovids>> call, Throwable t) {
//                Toast.makeText(StateCases.this, "Failed to Load", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
}